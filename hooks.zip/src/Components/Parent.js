import Child from "./Child";
import "./Content.css"
export default function Parent(){
    return(
        <div className="reactPage">
            <Child 
            heading="Declarative"
            para="Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud"
            />
            <Child
            heading="Content"
            para="Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud"
            />
            <Child
            heading="Information"
            para="Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud"
            />
        </div>
    )
        
    
}
