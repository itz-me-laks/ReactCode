import React from 'react'

function Child(Props) {
  return (
    <div style={{border:'5px solid yellow'}}>
        <h1>{Props.heading}</h1>
        <p>{Props.para}</p>
    </div>
  )
}

export default Child