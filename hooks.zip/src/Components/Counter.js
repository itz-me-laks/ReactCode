import React, {useState} from 'react'

function Counter() {
    //usestate hooks
    //to define variables whose values are going to be change
    // const [counter,setCounter]=useState(0)
    //counter-- variable setCounter-- it is function that used to update the value of count
    //0 initial value of counter
    //setCounyter is in build function
    let [counter,setCounter]=useState(9)
    function incre(){
      setCounter(++counter)
    }
    function decre(){
      setCounter(--counter)
    }
  return (
    <div>
        <div>{counter}</div>
        <button onClick={incre}>Increment</button>
        <button onClick={()=>setCounter(0)}>Reset</button>
        <button onClick={decre}>Decrement</button>
        
    </div>
  )
}

export default Counter