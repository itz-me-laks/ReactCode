import "./App.css";
import Counter from "./Components/Counter";
import HooksConcept from "./Components/Parent";


function App() {
  //do everything before return statement
  const arr = ["Home", "Contact", "SignUp", "About"];
  return (
    <div className="App">
      {/* <ul className="ulDesign">
        {arr.map((val) => {
          return <li>{val}</li>;
        })}
      </ul> */}
      <Counter/>
    </div>
  );
}

export default App;
